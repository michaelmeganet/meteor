put your images in this folder. We've removed them to make the file smaller to download. 

